#include <sys/stat.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <fcntl.h>
#include <math.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <errno.h>
#include <inttypes.h>
#include "dablooms.h"


//gcc test_dabloom.c -g -Wall -o test_dabloom -I/usr/local/include -L/usr/local/lib -ldablooms
void test_dev_zero_ftruncate(){
    const char *filename = "./test_ftruncate.txt";
    const char *filename1 = "/dev/zero";
    int fd = open(filename, O_RDWR | O_CREAT | O_TRUNC, (mode_t)0600);
    int fd1 = open(filename1, O_RDWR, (mode_t)0600);
    int new_size = 1024;
    if (ftruncate(fd, new_size) < 0) {
            printf("fail at ftruncate, errmsg = %s, fd = %d, filename = %s\n", strerror(errno), fd, filename);
    }
    else{
        printf("succeed at ftruncate, fd = %d, filename = %s\n", fd, filename);
    }
    if (ftruncate(fd1, new_size) < 0) {
            printf("fail at ftruncate, errmsg = %s, fd = %d, filename = %s\n", strerror(errno), fd1, filename1);
    }   
    else{
        printf("succeed at ftruncate, fd = %d, filename = %s\n", fd1, filename1);
    }
}

void test_mmap_and_ftruncate(){
    const char *filename = "./test_ftruncate.txt";
    int fd = open(filename, O_RDWR | O_CREAT | O_TRUNC, (mode_t)0600);
    int new_size = 10;
    if (ftruncate(fd, new_size) < 0) 
        printf("fail at ftruncate, errmsg = %s, fd = %d, filename = %s\n", strerror(errno), fd, filename);
    else
        printf("secceed ftruncate size = %d\n", new_size);
    char *p = (char*)mmap(0, new_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    *p = 'a';
    printf("*p = %c\n", *p);
    //ftruncate size = 0, then memory access error
    new_size = 0;
    if (ftruncate(fd, new_size) < 0) 
        printf("fail at ftruncate, errmsg = %s, fd = %d, filename = %s\n", strerror(errno), fd, filename);
    else
        printf("secceed ftruncate size = %d\n", new_size);
    printf("*p = %c\n", *p);
}


void test_private_anonymous_mmap(){
    int new_size = 100;
    char *p = (char*)mmap(NULL, new_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    *p = 'a';
    char *p1 = (char*)mmap(NULL, new_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    *p1 = 'b';
    printf("p = %c, p1 = %c\n", *p, *p1);
}


void test_scaling_bloom(){
    int capacity = 100;
	double error_rate = 0.05;

	scaling_bloom_t *bloom = new_scaling_bloom(capacity, error_rate);
    scaling_bloom_add(bloom, "aaa", 3, 1);
    printf("bloom add: key = aaa\n");

	scaling_bloom_t *bloom1 = new_scaling_bloom(capacity, error_rate);
    scaling_bloom_add(bloom1, "bbb", 3, 1);
    printf("bloom1 add: key = bbb\n");

	int hit = scaling_bloom_check(bloom, "aaa", 3);
	printf("bloom check: key = aaa, hit = %d\n", hit);

    hit = scaling_bloom_check(bloom, "bbb", 3);
	printf("bloom check: key = bbb, hit = %d\n", hit);
	
    hit = scaling_bloom_check(bloom1, "aaa", 3);
	printf("bloom1 check: key = aaa, hit = %d\n", hit);

	hit = scaling_bloom_check(bloom1, "bbb", 3);
	printf("bloom1 check: key = bbb, hit = %d\n", hit);
}

void test_expiry_dablooms(){
    unsigned int capacity = 100;
    double error_rate = 0.001;
    int expiry_time = 1;
    struct expiry_dablooms_handle *handle = expiry_dablooms_init(capacity, error_rate, expiry_time);
    uint64_t count = -1, i = 0;
    for(i = 0; i < 7; i++){
        expiry_dablooms_add(handle, "aaa", 3);
        expiry_dablooms_element_count_get(handle, &count);
        printf("element_count = %d\n", (int)count);
    }
    sleep(4);
    printf("After 4s:   \n");
    for(i = 0; i < 8; i++){
        expiry_dablooms_add(handle, "bbb", 3);
        expiry_dablooms_element_count_get(handle, &count);
        printf("element_count = %d\n", (int)count);
    }
    sleep(3);
    printf("After 7s:   \n");
    for(i = 0; i < 9; i++){
        expiry_dablooms_add(handle, "ccc", 3);
        expiry_dablooms_element_count_get(handle, &count);
        printf("element_count = %d\n", count);
    }
    expiry_dablooms_destroy(handle);
    /*
    int hit = expiry_dablooms_search(handle, "aaa", 3);
    uint64_t count = -1;
    expiry_dablooms_element_count_get(handle, &count);
    printf("key = aaa, hit = %d, element_count = %" PRIu64 "\n", hit, count);
    sleep(6);
    hit = expiry_dablooms_search(handle, "aaa", 3);
    count = -1;
    expiry_dablooms_element_count_get(handle, &count);
    printf("after 6s, key = aaa, hit = %d, element_count = %" PRIu64 "\n", hit, count);
    */
}



int main(){
    //test_scaling_bloom();
    test_expiry_dablooms();
	return 0;
}